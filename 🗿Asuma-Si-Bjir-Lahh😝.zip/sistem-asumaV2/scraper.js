const fetch = require("node-fetch");
const axios = require("axios");
//const got = require("got");
const FormData = require("form-data");
const cheerio = require("cheerio");
const { sizeFormatter } = require("human-readable");

  // Fungsi untuk fitur Google Gambar API
  async function google(q) {
    const response = await fetch(`https://www.google.com/search?q=${q}&tbm=isch`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.93 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
      },
    });

    const data = await response.text();
    const $ = cheerio.load(data);
    const pattern = /\[1,\[0,"(?<id>[\d\w\-_]+)",\["https?:\/\/(?:[^"]+)",\d+,\d+\]\s?,\["(?<url>https?:\/\/(?:[^"]+))",\d+,\d+\]/gm;
    const matches = $.html().matchAll(pattern);
    const decodeUrl = (url) => decodeURIComponent(JSON.parse(`"${url}"`));
    return [...matches]
    .map(({ groups }) => decodeUrl(groups?.url))
    .filter((v) => /.*\.jpe?g|png$/gi.test(v));
  }

  // Fungsi untuk mengkonversi Angka
  async function convertAngka(number) {
    return number.toLocaleString("en-US", {
      maximumFractionDigits: 2,
      notation: "compact",
      compactDisplay: "short"
    });
  }

  // Fungsi untuk fitur capcut downloader API
  async function ssscap(url) {
    return new Promise(async (resolve, reject) => {
      try {
        const res = await axios.get(`https://ssscap.net/api/download/get-url?url=${url}`, {
          headers: {
            cookie: "sign=94b3b2331a3515b3a031f161e6ce27a7; device-time=1693144685653",
          },
        });

        const tes = res.data.url;
        const parsedUrl = new URL(tes);
        const id = parsedUrl.searchParams.get("template_id");

        const result = await axios(`https://ssscap.net/api/download/${id}`, {
          headers: {
            cookie: "sign=4b0366645cd40cbe10af9aa18331a488; device-time=1693145535913",
          },
        });

        resolve(result.data);
      } catch (error) {
        reject(error);
      }
    });
  }

  // Fungsi untuk fitur tiktok search API
  async function tikwm(q) {
    return new Promise(async (resolve, reject) => {
      axios("https://tikwm.com/api/feed/search", {
        headers: {
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          cookie: "current_language=en",
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
        },
        data: {
          keywords: q,
          count: 12,
          cursor: 0,
          web: 1,
          hd: 1,
        },
        method: "POST",
      }).then((res) => {
        resolve(res.data.data);
      });
    });
  }

module.exports = { google, convertAngka, ssscap, tikwm };
