const fs = require("fs")
const os = require('os');

let handler = async (m, { Ditss, isCreator, isPremium, qtext, runtime, toIDR, qkontak, asumaSaldo, ditsganteng, fetchJson}) => {
`${ditsganteng}`
let teksnya = `
*\`乂 R P G - M E N U 乂\`*

> ┌  ◦ *${ki}mulung${ka}* : 
> └  ◦ *${ki}berburu${ka}* :
> ┌  ◦ *${ki}mining${ka}* : 
> └  ◦ *${ki}spin${ka}* :
> ┌  ◦ *${ki}global${ka}* : 
> └  ◦ *${ki}use-power${ka}* :
> ┌  ◦ *${ki}sell${ka}* : 
> └  ◦ *${ki}profile${ka}* :
> ┌  ◦ *${ki}buy${ka}* : 
> └  ◦ *${ki}exitrpg${ka}* :
> ┌  ◦ *${ki}joinrpg${ka}* : 
> └  ◦ *${ki}joinguild${ka}* :
> ┌  ◦ *${ki}delguild${ka}* : 
> └  ◦ *${ki}listguild${ka}* :
> ┌  ◦ *${ki}createguild${ka}* : 
> └  ◦ *${ki}guildinfo${ka}* :
> ┌  ◦ *${ki}myguild${ka}* : 
> └  ◦ *${ki}battle${ka}* : <6281xx>
> ┌  ◦ *${ki}rejec-battle${ka}* : 
> └  ◦ *${ki}acc-battle${ka}* :
> ┌  ◦ *${ki}daily${ka}* : 
> └  ◦ *${ki}weekly${ka}* :
> ┌  ◦ *${ki}setname${ka}* : 
> └  ◦ *${ki}mancing${ka}* :
> ┌  ◦ *${ki}kurir${ka}* : 
> └  ◦ *${ki}give-food${ka}* :
> ┌  ◦ *${ki}recoper${ka}* : 
> └  ◦ *${ki}sleep${ka}* :
> ┌  ◦ *${ki}bermain${ka}* : 
> └  ◦ *${ki}my-toki${ka}* :
> ┌  ◦ *${ki}latih-toki${ka}* : 
> └  ◦ *${ki}cari-rpg${ka}* :
> ┌  ◦ *${ki}musuh${ka}* : 
> └  ◦ *${ki}get-toki${ka}* :
> ┌  ◦ *${ki}lamar-kerja${ka}* : 
> └  ◦ *${ki}out-kerja${ka}* :
> ┌  ◦ *${ki}polisi${ka}* : 
> └  ◦ *${ki}ojek${ka}* :
> ┌  ◦ *${ki}hauling${ka}* : 
> └  ◦ *${ki}petani${ka}* :
> ┌  ◦ *${ki}dagang${ka}* : 
> └  ◦ *${ki}pedagang${ka}* :
> ┌  ◦ *${ki}depositbank${ka}* : 
> └  ◦ *${ki}tarikbank${ka}* :
> ┌  ◦ *${ki}cardbank${ka}* : 
> └  ◦ *${ki}getcard${ka}* :
> ┌  ◦ *${ki}bank${ka}* : 
> └  ◦ *${ki}info-bank${ka}* :

fitur ini akan hadir di next update🗿.
`
await Ditss.sendMessage(m.chat, {document: fs.readFileSync("./asuma-Ditss.js"), mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", caption: `${teksnya}`, fileName: `${botname2} V${global.versi}`, contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${global.botname}`, newsletterJid: global.idSaluran }, 
mentionedJid: [global.owner+"@s.whatsapp.net", m.sender], externalAdReply: {containsAutoReply: true, thumbnail: await fs.readFileSync("./source/media/menu.jpg"), title: `© Copyright By ${namaOwner}`, 
renderLargerThumbnail: true, sourceUrl: global.linkSaluran, mediaType: 1}}}, {quoted: qtext})
let pler = await fetchJson('https://raw.githubusercontent.com/ditss-dev/musikk/main/randomm.json');

let itil = pler[Math.floor(Math.random() * pler.length)];
await Ditss.sendMessage(m.chat, { audio:{url: itil},mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: qkontak })}

handler.command = ["menurpg", "rpgmenu", "asuma-rpg"]

module.exports = handler