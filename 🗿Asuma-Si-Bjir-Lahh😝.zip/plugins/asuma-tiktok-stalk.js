const fetch = require('node-fetch');
let handler = async (m, { Ditss, text, Reply,fetchJson, convertAngka }) => {
if (!text) return Reply(`contoh ${prefix + command} paadit`)
try {
let result = await fetchJson(`https://api.vreden.my.id/api/tiktokStalk?query=${text}`)
let post = await convertAngka(result.result.stats.videoCount)
let follwer = await convertAngka(result.result.stats.followerCount)
let follwing = await convertAngka(result.result.stats.followingCount)
let likes = await convertAngka(result.result.stats.heartCount)
let fien = await convertAngka(result.result.stats.friendCount)
let response = `
*乂 TIKTOK - STALK*
📛 *Nickname :* ${result.result.user.nickname}
👤 *Username :* ${result.result.user.uniqueId}
📸 *Postingan :* ${post}
👥 *Pengikut :* ${follwer}
➡️ *Mengikuti :* ${follwing}
❤️ *Suka :* ${likes}
🤝 *Teman :* ${fien}
📝 *Bio :* ${result.result.user.signature}
`.trim();
Ditss.sendMessage(m.chat, { image: { url: result.result.user.avatarLarger }, caption: response}, {quoted: m})
} catch (err) {
console.log(err)
Reply(mess.error)
}
};

handler.command = ["ttstalk", "tiktokstalk"];

module.exports = handler;