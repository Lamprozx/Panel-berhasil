const fs = require('fs');
const timeout = 1800000

let handler = async (m, { Ditss, prefix, text, reply, sleep }) => {
global.db.users[m.sender].lastwaktu += 1800000;
	    let time = global.db.users[m.sender].lastwaktu += 1800000;
  if (new Date - global.db.users[m.sender].lastwaktu< 1800000) throw `Anda sudah lelah untuk mulung\nTunggu selama ${msToTime(time - new Date())} lagi`
fs.readdir("./session", async function (err, files) {
if (err) {
console.log('Unable to scan directory: ' + err);
return reply('Unable to scan directory: ' + err);
} 
let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
 )
console.log(filteredArray.length); 
let teks =`Terdeteksi ${filteredArray.length} file session\n\n`
if(filteredArray.length == 0) return reply(`${teks}`)
filteredArray.map(function(e, i){
teks += (i+1)+`. ${e}\n`
}) 
reply(`${teks}`) 
await sleep(2000)
reply("Menghapus file session")
await filteredArray.forEach(function (file) {
fs.unlinkSync(`./session/${file}`)
});
await sleep(2000)
reply("Berhasil menghapus semua Kenangan di folder session") 
});
  setTimeout(() => {
m.reply(`Yuk waktunya delete session lagi`, m)
					}, timeout)
}
handler.command = ["delsesi", "delses", "delete-session"]

module.exports = handler

function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24)
    
  
  hours = (hours < 10) ? "0" + hours : hours
  minutes = (minutes < 10) ? "0" + minutes : minutes
  seconds = (seconds < 10) ? "0" + seconds : seconds

  return hours + " jam " + minutes + " menit " + seconds + " detik"
}