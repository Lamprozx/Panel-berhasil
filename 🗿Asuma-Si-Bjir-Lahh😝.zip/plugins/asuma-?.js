const fs = require("fs")
const os = require('os');
let handler = async (m, { Ditss, isCreator, isPremium, qtext, runtime, toIDR, qkontak, asumaSaldo, ditsganteng, pickRandom, readmore, fetchJson, salam }) => {

const asumaByDits = `
*\`乂 JADIBOT - M E N U 乂\`*

> ┌  ◦ *jadibot* : 
> └  ◦ *jadibot-scan* :
> ┌  ◦ *jadibot-pairing* : 
> └  ◦ *list-jadibot* :
> ┌  ◦ *start-jadibot* : 
> └  ◦ *stop-jadibot* :
> ┌  ◦ *repses-jadibot* : 
> └  ◦ *renew-jadibot* :`
const resize = async(buffer, ukur1, ukur2) => {
 return new Promise(async(resolve, reject) => {
 let jimp = require('jimp')
 var baper = await jimp.read(buffer);
 var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
 resolve(ab)
 })
}
Ditss.sendMessage(m?.chat, {
    document: fs.readFileSync("./package.json"),
    jpegThumbnail: fs.readFileSync("./source/media/menu.jpg"),
    fileName: `${salam} ${m.pushName}`,
    
    fileLength: 99999999999999,
    pageCount: "100",
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
//bts
 caption: asumaByDits,
 footer: `powered by ${namaOwner}`,
 buttons: [
 {
 buttonId: ".jadibot-pairing", 
 buttonText: {
 displayText: 'jadibot pairing'
 }
 }, {
 buttonId: ".jadibot-scan", 
 buttonText: {
 displayText: "jadibot scan"
 }
 }
],
 viewOnce: true,
 headerType: 6,
 contextInfo: {
 isForwarded: true,
 forwardingScore: 99999,
 externalAdReply: {
 showAdAttribution: true,
 title: `${namaOwner} | ${botname2}`,
 mediaType: 1,
 previewType: 1,
 body: `® Ditss`,
 //previewType: "PHOTO",
 thumbnail: fs.readFileSync('./source/media/bibir.jpg'),
 renderLargerThumbnail: true,
 mediaUrl: linkGrup,
 sourceUrl: linkGrup,
 },
 forwardedNewsletterMessageInfo: {
 newsletterJid: idSaluran,
 serverMessageId: -1,
 newsletterName: `Menu By: ${namaOwner}`,
 }
 }
}, { quoted: qkontak });
let pler = await fetchJson('https://raw.githubusercontent.com/ditss-dev/musikk/main/randomm.json');

let itil = pler[Math.floor(Math.random() * pler.length)];
await Ditss.sendMessage(m.chat, { audio:{url: itil},mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: qkontak })}


handler.command = ["menujadibot", "jadibotmenu", "asuma-jadibot", "jadibot"]

module.exports = handler